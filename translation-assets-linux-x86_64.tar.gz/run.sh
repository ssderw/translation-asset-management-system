#!/usr/bin/env bash
# 翻译资产管理系统 启动脚本
set -e

DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"

echo "========================================"
echo "  翻译资产管理系统"
echo "========================================"

# 加载 .env 配置（如果存在）
if [ -f .env ]; then
    echo "[*] 加载 .env 配置文件..."
    set -a
    source .env
    set +a
fi

echo "[*] 正在启动服务..."
exec "$DIR/translation-assets" "$@"
